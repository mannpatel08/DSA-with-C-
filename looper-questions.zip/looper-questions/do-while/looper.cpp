#include <iostream>
using namespace std;

int main() {


// Question 1   sum of natural number 

    // int natural;
    // int i = 1;
    // int sum = 0;
    
    // cout << "Enter a number: ";
    // cin >> natural;

    // do
    // {
    //     sum = sum + i;
    //     i++;

    // } while (i <= natural);
    

    // cout << "Sum of first " << natural << " natural numbers is: " << sum << endl;


// Question 2   product of natural number 

    // int natural;
    // int i = 1;
    // int product = 1;
    
    // cout << "Enter a number: ";
    // cin >> natural;

    // do
    // {
    //     product = product * i;
    //     i++;

    // } while (i <= natural);
    

    // cout << "Sum of first " << natural << " natural numbers is: " << product << endl;


// Question 3    total digit in a number

    // int num;
    // int total = 0;

    // cout<<"Enter Number : ";
    // cin>>num;

    // do
    // {
    //     num = num / 10;
    //     total++;

    // } while (num > 0);
    
    // cout<<"Total Digit : "<<total;



// Questions 4   reverse a number

    // int num;
    // int rev_num;

    // cout<<"Enter Number : ";
    // cin>>num;

    // do
    // {
    //     rev_num = rev_num * 10 + num % 10;
    //     num = num / 10;

    // } while (num > 0);

    // cout<<"Reversed Number : "<<rev_num;



// Question 5   Checkk pallindrom


    // int num;
    // int rev_num;

    // cout<<"Enter Number : ";
    // cin>>num;

    // int num_2 = num;

    // do
    // {
    //     rev_num = rev_num * 10 + num % 10;
    //     num = num / 10;


    // } while (num > 0);


    // if (rev_num == num_2)
    // {
    //     cout<<"Pallindrom";
    // }else{
    //     cout<<"Not Pallindrom";
    // }


// Question 6   factorial of a no.

    
    // int start; 
    // int end = 1; 

    // cout<<"Enter Number : ";
    // cin>>start;

    // do
    // {
    //     end = end * start;
    //     start -- ;
    // } while (start >= 1);

    // cout<<"Factorial : "<<end;


// Questtion 7  sum of digits


    // int num;
    // int sum = 0;
    
    // cout << "Enter number: ";
    // cin >> num;

    // do
    // {
    //     sum = sum + num % 10;  
    //     num = num / 10; 
    // } while (num > 0);

    // cout << "Sum : " << sum << endl;


// Question 8  check prime number


    // int i = 2 ;
    // int n;

    // cout<<"Enter Number : ";
    // cin>>n;

    // do
    // {
    //   if (n % i == 0)
    //    {
    //     cout<<"not a prime number ";
    //     break;
    //    }
    //    i++;
    // } while (i < n);

    // if(n == i){
    //     cout<<"prime number";
    // }
    
    
// Question 9   fibonacci series


    // int a = 0 ;
    // int b = 1 ;
    // int c ;
    // int num ;
    // int i = 0;

    // cout<<"Enter Number : ";
    // cin>>num;
    

    // do
    // {
    //  if(i <= 1){
    //         c = i;
    //     }else{
    //         c = a + b;
    //         a = b; 
    //         b = c;
    //     }
    //     i++;
    //     cout<<c<<"  ";
    // } while (i < num);






}
