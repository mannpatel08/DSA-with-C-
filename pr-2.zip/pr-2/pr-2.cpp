#include<iostream>
using namespace std;

int main()
{
    
    
// Question 1

    // char start = 'a';
    // char end = 'z';

    // do
    // {
    //     cout<<start<<" ";
    //     start = start + 4;

    // } while (start<=end);
    

// Question 2

    // int num;
    // int tot = 0;

    // cout<<"Enter Number : ";
    // cin>>num;

    // while (num>0)
    // {
    //     tot++;
    //     num = num / 10;
    // }
    // cout<<"Total Ditig : "<<tot;


// Questions 3

    // int num = 319;
    // int last = num % 10;
    // int first = 0;


    // while (num>0)
    // {
    //     first = num;
    //     num = num / 10;
    // }
    
    // cout<<last+first;





}